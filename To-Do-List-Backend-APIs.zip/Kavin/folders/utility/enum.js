const TASKSTATUS = {
    NEW: 'NEW',
    PENDING: 'PENDING',
    COMPLETED: 'COMPLETED'
}

module.exports = { TASKSTATUS };